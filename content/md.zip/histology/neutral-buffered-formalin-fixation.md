Date: 2011-07-15 09:07
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: Neutral buffered formalin fixation
Slug: methods/30/neutral-buffered-formalin-fixation
Tags: histology,buffer,fixation,media &amp; solutions

Fixation with neutral buffered formalin









To produce 10L pour a base 1L distilled water into a suitable container.



Add 40g sodium dihydrogen orthophosphate (monohydrate)



Add 65g disodium hydrogen orthophosphate (anhydrous)



Add 1L formaline (40% aqueous solution of formaldehyde)



Add a further 8L water for use



Immerse samples and fix for 12-24 hours



Samples may be stored in this fixative if required





