Date: 2011-07-15 09:07
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: Formol sublimate fixation
Slug: methods/28/formol-sublimate-fixation
Tags: histology,fixation

Fixation in formol sublimate









In a fume hood pour 100ml formalin (40% aqueous solution of formaldehyde) into a suitable container



Add 900ml saturated aqueous mercuric chloride



Submerge tissue and fix for 4-6 hours



Remove fixed tissue and transfer to 80% alcohol to store





