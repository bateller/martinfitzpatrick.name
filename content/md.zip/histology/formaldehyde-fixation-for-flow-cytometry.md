Date: 2011-07-16 02:07
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: Formaldehyde fixation for flow cytometry
Slug: methods/35/formaldehyde-fixation-for-flow-cytometry
Tags: histology,rna,fixation,molecular biology

Alternative fixation procedure for FACS fixation, using formaldehyde fixatice.









Fix cells with 2% fresh formaldehyde in PBS for 5-15min, gentle rotation may
help to improve fixation



Wash cells 2-3 times with PBS to remove all of the formaldehyde



Resuspend cells in 300ul of PBS 



Add 700ul of 100% -20°C EtOH to permeabilize the cells - they can now optionally be stored for weeks at –20°C.



Permeabilize cells with 0.1% TritonX-100 in PBS for 15min





