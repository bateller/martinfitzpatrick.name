Date: 2012-02-20 09:02
Author: Luke Hammond
Email: l.hammond@uq.edu.au
Title: Dewaxing Paraffin Sections
Slug: methods/1452/dewaxing-paraffin-sections
Tags: histology,dewaxing,paraffin section,xylene

Dewaxing Paraffin Sections Sections must be free of wax to allow aqueous solutions to penetrate.




>Cryostat and free floating sections may need defatting prior to immunhistochemical staining. This must be optimised by the user




#Method

Xylene x2 (2-3mins)



Absolute ethanol x2 (2-3mins)



Water wash.





