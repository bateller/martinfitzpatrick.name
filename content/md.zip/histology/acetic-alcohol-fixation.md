Date: 2011-07-16 02:07
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: Acetic alcohol fixation
Slug: methods/25/acetic-alcohol-fixation
Tags: histology,fixation,cytofix,fixative

Fixative for smears, cytospin preparations and frozen sections









Add 3ml glacial acetic acid to 100ml 95% methanol



Fix section in solution for 1 minute



Rinse section in distilled water prior to staining





