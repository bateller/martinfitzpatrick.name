Date: 2011-07-15 09:07
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: Carnoy&#39;s fluid fixation
Slug: methods/27/carnoys-fluid-fixation
Tags: histology,fixation

Fixation of samples in Carnoy's fluid









In a fume hood pour 60ml of ethanol into a suitable container



Add 30ml choloroform



Add 10ml glacial acetic acid to give a total volume of 100ml



Place tissue into fixative for 1-3 hours



Process fixed tissues immediately or transfer to 80% alcohol for storage





