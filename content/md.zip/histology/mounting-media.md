Date: 2011-10-10 10:10
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: Mounting Media
Slug: methods/1340/mounting-media
Tags: histology,media,mounting,media &amp; solutions

Mounting Media





#Requirements
20mM Tris pH 8.0
0.5% N-propyl gallate
90% Glycerol 

#Method

Combine ingredients in suitable container. Store for use.


>Store at 4oC.




