Date: 2011-08-21 01:08
Author: Matt Lewis
Email: hop2kin@yahoo.co.uk
Title: DNA extraction from agarose gels (Spin-column)
Slug: methods/119/dna-extraction-from-agarose-gels-spin-column
Tags: dna,molecular biology,extraction,agarose

These are excellent for extracting DNA if you can afford them. They cost 1–2 US$ each. Manufacterers include Qiagen, Sigma, Novagen









Dissolve the gel-slice in 3 volumes of chaotropic agent at 50C for 10 minutes



Apply the solution to a spin-column and spin for 1 minute (the DNA remains in the column)



Wash the column by passing 70% ethanol through (the DNA remains in the column, salt and impurities are washed out)



Elute the DNA in a small volume (30µL) of water or buffer, spin to collect. 





