Date: 2011-11-06 07:11
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: Execute last command as root
Slug: methods/1503/execute-last-command-as-root
Tags: unix,linux,sudo,root,computing

Re-run previously entered command as root user.









    sudo !!


>`!!` is automatically substituted to the content of the previous command. Turning the above line into `sudo <your command here>`.




