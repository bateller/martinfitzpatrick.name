Date: 2011-10-11 12:10
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: L B Broth
Slug: methods/1369/l-b-broth
Tags: media,culture,broth,lb,media &amp; solutions

L B Broth





#Requirements
1 liter of ddH2O
10 grams Bacto-tryptone
5 grams Bacto-yeast Extract
5 grams NaCl

#Method

In 1 liter of ddH2O combine 10 grams Bacto-tryptone, 5 grams Bacto-yeast Extract and 5 grams NaCl



Stir until dissolved.



Autoclave for at least 15min @120C



Once cooled below 55C add antibiotic of choice and store at 4C. Use within 2 weeks





