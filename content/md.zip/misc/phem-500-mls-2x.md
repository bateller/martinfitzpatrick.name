Date: 2011-10-10 10:10
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: PHEM (500 mls) 2x 
Slug: methods/1338/phem-500-mls-2x
Tags: phem

PHEM (500 mls) 2x 





#Requirements
18.14 g Pipes
6.5 g Hepes
3.8 g EGTA
0.99 g MgSO4

#Method

Combine in beaker. Bring pH to pH7.0 with addition of KOH.





