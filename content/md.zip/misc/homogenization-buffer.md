Date: 2011-10-10 11:10
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: Homogenization Buffer
Slug: methods/1347/homogenization-buffer
Tags: buffer,pmsf,media &amp; solutions

Homogenization Buffer





#Requirements
300 ml PM buffer
52.3 mg PMSF (1mM PMSF)
3 g leupeptin (10 mg/ml leupeptin)
300 mg pepstatin A (1 ug/ml pepstatin A)
3 mg TAME (10 ug/ml TAME) 

#Method

Combine ingredients in suitable container. Mix well to dissolve.


>Use immediately.




#References


Clare M. Waterman-Storer [Microtubule/Organelle Motility Assays](http://dx.doi.org/10.1002/0471143030.cb1301s00)  (2001)
[10.1002/0471143030.cb1301s00](http://dx.doi.org/10.1002/0471143030.cb1301s00)



