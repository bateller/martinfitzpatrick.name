Date: 2011-10-10 10:10
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: Valap
Slug: methods/1342/valap
Tags: vaseline,lanolin,paraffin,valap

Valap





#Requirements
50 g vaseline
50 g lanolin
50 g paraffin

#Method

Combine 50 g Vaseline, 50 g lanolin, and 50 g paraffin into a 1L Pyrex beaker 



Heat gently on hotplate, stirring occasionally, until components have melted and are well-mixed.



Aliquot into small screw-cap jars (~50 ml capacity) for storage.


>Store at room temperature




#References


Clare M. Waterman-Storer [Microtubule/Organelle Motility Assays](http://dx.doi.org/10.1002/0471143030.cb1301s00)  (2001)
[10.1002/0471143030.cb1301s00](http://dx.doi.org/10.1002/0471143030.cb1301s00)



