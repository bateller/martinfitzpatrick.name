Date: 2011-10-10 11:10
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: 5 M NaCl
Slug: methods/1360/5-m-nacl
Tags: nacl,media &amp; solutions

5 M NaCl





#Requirements
292.2 g NaCl
1L distilled water

#Method

Add 292.2 g NaCl to a suitable container. Add distilled water up to a final volume of 1litre. Store until further use.


>Store at room temperature




#References


Clare M. Waterman-Storer [Microtubule/Organelle Motility Assays](http://dx.doi.org/10.1002/0471143030.cb1301s00)  (2001)
[10.1002/0471143030.cb1301s00](http://dx.doi.org/10.1002/0471143030.cb1301s00)



