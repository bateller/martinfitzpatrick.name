Date: 2012-02-05 05:02
Author: Ian Chin-Sang
Email: chinsang@queensu.ca
Title: M9 Plates -Leu
Slug: methods/1428/m9-plates-leu
Tags: plates,m9,leu

The following recipe is for one litre of plates.  




>The salts need to be autoclaved separately from the agar, for this reason prepare the following two mixtures in flasks (make sure one is a 2 litre flask since you are going to combine the mixes after autoclaving):




#Method

Mix 1: Salt mix in 500ml of water:

* 6g Na2HP04
* 3g KH2P04
* 0.5g NH4Cl




Mix 2:  Agar:

* 15g Agar
* 500ml Water




Autoclave mixes 1 and 2—after autoclaving combine the two mixes and add the following sterile solutions to the mixture:

* 1ml 1M MgSO4
* 0.1ml 1MCaCl2
* 4.0ml 50% Glucose (filter sterilized)
* 0.69g -Leu Drop Out




Pour plates and label appropriately.  1L = ~40 plates





