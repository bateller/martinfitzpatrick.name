Date: 2012-02-20 09:02
Author: Luke Hammond
Email: l.hammond@uq.edu.au
Title: Sodium Citrate Buffer
Slug: methods/1454/sodium-citrate-buffer
Tags: buffer,sodium citrate,media &amp; solutions

10mM Sodium Citrate, 0.05% Tween 20, pH 6.0





#Requirements
Tri-sodium citrate (dihydrate) 2.94 g
Distilled water 1000 ml


#Method

Mix to dissolve.



Adjust pH to 6.0 with 1N HCl.



Add 0.5 ml of Tween 20 and mix well.





