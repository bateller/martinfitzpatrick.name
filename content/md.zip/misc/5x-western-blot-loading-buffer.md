Date: 2011-07-16 02:07
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: 5x Western blot loading buffer
Slug: methods/19/5x-western-blot-loading-buffer
Tags: buffer,western blot,sample dye,loading buffer,media &amp; solutions

15ml stock solution of western blot loading buffer. Dilute for use.









To prepare base solvent add 3ml 20% SDS to add 3.75mL 1M Tris buffer at pH 6.8 in a suitable container.



Add 9 mg bromphenol blue, 1.16 gm DTT (or 2.4ml B-mercaptoethanol) and mix well.



Add 4.5mL glycerol to the solution, mix well.



Make up to a final volume of 15ml with dH20 and mix again thoroughly



Store at 4'C. Dilute to use.





