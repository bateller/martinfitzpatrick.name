Date: 2012-02-20 09:02
Author: Luke Hammond
Email: l.hammond@uq.edu.au
Title: Chrome Alum Gelatin Slide Coating
Slug: methods/1455/chrome-alum-gelatin-slide-coating
Tags: coating,slides,chrome alum

Chrome Alum Gelatin Slide Coating




>Clean grease-free slides are needed for the slide coating to be effective.


#Requirements
200ml Distilled water
0.5g Gelatin
0.05g Chromic potassium Sulphate



#Method

Microwave briefly to dissolve the gelatin



Cool



Dip clean slides and allow to drain vertically.



Once completely dry pack into Slide boxes in a dust free environment.





