Date: 2012-02-05 03:02
Author: Ian Chin-Sang
Email: chinsang@queensu.ca
Title: 2X Rapid Ligation Buffer
Slug: methods/1418/2x-rapid-ligation-buffer
Tags: buffer,rapid ligation,media &amp; solutions

2X Rapid Ligation Buffer (ProMega)





#Requirements
60mM Tris-HCl (pH 7.8)
20mM MgCl2
20mM DTT
2mM ATP
10% polyethylene glycol

#Method

Combine ingredients in suitable container.





