Date: 2011-07-16 02:07
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: 10% Ammonium persulphate solution
Slug: methods/20/10-ammonium-persulphate-solution
Tags: ammonium persulphate,acrylamide

10% solution









Add dH20 to Falcon tube or other suitable container for the volume. 



Add 1g Ammonium persulphate per 10 ml water 

e.g. 50mls add 5g APS

Mix thoroughly - APS will dissolve readily.



Solution may be stored at 4'C up to 6 months





