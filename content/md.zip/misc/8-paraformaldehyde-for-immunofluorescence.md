Date: 2012-02-20 09:02
Author: Luke Hammond
Email: l.hammond@uq.edu.au
Title: 8% Paraformaldehyde for Immunofluorescence
Slug: methods/1456/8-paraformaldehyde-for-immunofluorescence
Tags: paraformaldehyde,immunofluorescence

8% Paraformaldehyde for Immunofluorescence









Add 16g paraformaldehyde to approximately 160ml water in fume hood.



Heating on setting 4.5 whilst stirring to 50ºC.



Once temperature reaches 50ºC, 1M NaOH until the paraformaldehyde is just dissolved.



Make up to final volume of 200ml with water, pH to 7.2-7.4.



Filter with 0.22µm filter.



Aliquot in 5ml tubes, label and freeze.





