Date: 2011-07-16 02:07
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: 10x Tris Buffer
Slug: methods/21/10x-tris-buffer
Tags: buffer,media &amp; solutions

Recipe for 10x Tris Buffer, dilute for use









Fill suitable container with 1L dH20



Add 30g Tris, 88g NaCl and 2g KCl to the solution, mixing thoroughly until fully dissolved.



Adjust pH to 7.5 with HCl





