Date: 2011-10-10 11:10
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: 1M dithiothreitol (DTT)
Slug: methods/1355/1m-dithiothreitol-dtt
Tags: dtt

1M dithiothreitol (DTT)





#Requirements
1.542 g dithiothreitol
10ml Distilled water

#Method

Add dithiothreitol to a suitable container. Make up to 10ml with distilled water.



Aliquot in 500 ml volumes and store at -20oC for future use.


>Store at -20oC




#References


Clare M. Waterman-Storer [Microtubule/Organelle Motility Assays](http://dx.doi.org/10.1002/0471143030.cb1301s00)  (2001)
[10.1002/0471143030.cb1301s00](http://dx.doi.org/10.1002/0471143030.cb1301s00)



