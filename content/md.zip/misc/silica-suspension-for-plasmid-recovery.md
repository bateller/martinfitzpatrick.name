Date: 2012-03-21 03:03
Author: Ian Chin-Sang
Email: chinsang@queensu.ca
Title: Silica Suspension for plasmid recovery
Slug: methods/1469/silica-suspension-for-plasmid-recovery
Tags: plasmid,silica,slurry

Silica Suspension for plasmid recovery









Suspend 2-10  grams of Silica (Sigma S-5631) in 20 mls H2O



 Allow to settle for 2 hours



Remove milky supernatant and suspend settled silica in 20 mls H2O



Allow to settle for 2 hours (repeat 3 times)



Estimate volume and resuspend silica in 2 vols 6M Guanidine Hydrochloride-1M KOAc buffer, pH 5.5.





