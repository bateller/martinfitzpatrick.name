Date: 2011-10-10 11:10
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: 1M MgSO4
Slug: methods/1350/1m-mgso4
Tags: media &amp; solutions

1M MgSO4





#Requirements
24.074 g MgSO4

#Method

Add MgSO4 to suitable container. Make up to 200ml with distilled water.


>Store at room temperature




#References


Clare M. Waterman-Storer [Microtubule/Organelle Motility Assays](http://dx.doi.org/10.1002/0471143030.cb1301s00)  (2001)
[10.1002/0471143030.cb1301s00](http://dx.doi.org/10.1002/0471143030.cb1301s00)



