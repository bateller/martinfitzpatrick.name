Date: 2011-10-10 11:10
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: 0.5 M EGTA Stock
Slug: methods/1354/05-m-egta-stock
Tags: egta,media &amp; solutions

0.5 M EGTA Stock





#Requirements
19.02 g EGTA (Sodium Salt)
Distilled water

#Method

Add ingredients to suitable container. Add distilled water up to 90 ml



Adjust pH to 7.0



Add distilled water up to a final volume of 100 ml. Store for later use.


>Store at room temperature.




#References


Clare M. Waterman-Storer [Microtubule/Organelle Motility Assays](http://dx.doi.org/10.1002/0471143030.cb1301s00)  (2001)
[10.1002/0471143030.cb1301s00](http://dx.doi.org/10.1002/0471143030.cb1301s00)



