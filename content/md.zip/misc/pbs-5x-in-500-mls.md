Date: 2011-10-10 10:10
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: PBS (5x in 500 mls)
Slug: methods/1339/pbs-5x-in-500-mls
Tags: buffer,pbs,media &amp; solutions

PBS (5x in 500 mls)


![method/1339/800px-Laboratory_glass_bottles-set.jpg](/static/images/method/1339/800px-Laboratory_glass_bottles-set.jpg)




#Requirements
20.45 g NaCl
0.465 g KCl
10.142 g Na2HPO4*7 H2O
0.545 g KH2PO4

#Method

Add 500ml distilled water to a suitable container. 



Add ingredients to water and pH to 7.2





