Date: 2011-10-10 10:10
Author: Martin Fitzpatrick
Email: martin.fitzpatrick@gmail.com
Title: 50 mM Tris pH 8.0 10 mM EDTA
Slug: methods/1337/50-mm-tris-ph-80-10-mm-edta
Tags: tris,edta

50 mM Tris pH 8.0 10 mM EDTA





#Requirements
50 mM 1 M Tris pH 8.0 5 ml
1 mM 0.5 M EDTA 2 ml 
H2O up to 100 ml 

#Method

Combine Tris & EDTA to final volume of 7ml



Add H2O up to 100 ml 


>Store at 4'C




